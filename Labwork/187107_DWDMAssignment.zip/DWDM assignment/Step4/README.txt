The implementation of step 4 uses a dataset which is downloaded from kaggle.com

The python notebook for its vizualisation and analysis can be viewed on jupyter notebooks
and also on google colab.

alternatively you can view on kaggle.com itself by following the give link.

Link: https://www.kaggle.com/anshumansingh309/notebook3bc44378ca

Thank you!
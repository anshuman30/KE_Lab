Name: Anshuman Singh
Roll: 187107
B.Tech CSE 3rd year

KE LAB ASSIGNMENT 5

The assignment consists of 2 solution files for the 2 questions and also 2 files for input and output:
Q1 - q1.cpp
Q2 - q2.cpp

q1.cpp-
This file has the implementation of Apriori Algorithm using the join step to generate 
all the frequent itemsets and also generate association rules for the corresponding frequent itemsets.
There are 3 cases taken with minimum support = 20%, 30% and 50%. For each case the frequent
itemsets are generated from the transaction database and association rules are also calculated.
Minimum confidence for all 3 cases is assumed to be = 0.5.

q2.cpp-
This file has the implementation of Apriori Algorithm using the join step and prune step
to generate all frequent itemsets and their corresponding association rules. Here also
3 cases has been taken same as above.
NOTE: To check my implementation of Prune step, please go to line number 83 of q2.cpp file.

BONUS: I have also provided with one more file "db_gen.cpp" which can be used to generate
random dataset of teansactions and check my solution with random datasets. Please be 
aware that the result of many of the random datasets can be empty or very huge.

Thank you.